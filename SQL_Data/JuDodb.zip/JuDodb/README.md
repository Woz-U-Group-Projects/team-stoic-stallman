# JuDodb
 Group project demo Database.
